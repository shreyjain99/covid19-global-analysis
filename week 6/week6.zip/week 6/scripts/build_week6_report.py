"""Build the Week 6 status report PDF (interactive Plotly charts for case & death trends)."""
from pathlib import Path
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Image,
                                Table, TableStyle, HRFlowable, ListFlowable, ListItem)

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FIG = ROOT / "figures"
OUT = ROOT / "Week6_Update_Interactive_Charts.pdf"

NAVY = colors.HexColor("#12395e"); BLUE = colors.HexColor("#1f6fb4")
GREY = colors.HexColor("#555555"); LIGHT = colors.HexColor("#eef3f8")

styles = getSampleStyleSheet()
styles.add(ParagraphStyle("H", parent=styles["Title"], fontSize=19, textColor=NAVY,
                          spaceAfter=2, alignment=TA_LEFT, leading=22))
styles.add(ParagraphStyle("Sub", fontName="Helvetica", fontSize=9.5, textColor=GREY, spaceAfter=10))
styles.add(ParagraphStyle("Sec", parent=styles["Heading2"], fontSize=12.5, textColor=BLUE,
                          spaceBefore=12, spaceAfter=5))
styles.add(ParagraphStyle("Body", parent=styles["Normal"], fontSize=10, leading=14.5,
                          textColor=colors.HexColor("#222222"), spaceAfter=5))
styles.add(ParagraphStyle("Cap", fontName="Helvetica-Oblique", fontSize=8.5, textColor=GREY,
                          spaceBefore=2, spaceAfter=10, alignment=1))
styles.add(ParagraphStyle("Bull", parent=styles["Body"], leftIndent=6, spaceAfter=3))

story = []


def rule():
    story.append(Spacer(1, 3))
    story.append(HRFlowable(width="100%", thickness=0.7, color=colors.HexColor("#cdd9e5")))
    story.append(Spacer(1, 3))


def bullets(items):
    story.append(ListFlowable(
        [ListItem(Paragraph(t, styles["Bull"]), leftIndent=12, value="\u2022") for t in items],
        bulletType="bullet", start="\u2022", leftIndent=10))


def figure(name, caption, width=6.6 * inch):
    img = Image(str(FIG / name)); r = img.imageHeight / img.imageWidth
    img.drawWidth = width; img.drawHeight = width * r; img.hAlign = "CENTER"
    story.append(img); story.append(Paragraph(caption, styles["Cap"]))


# Header
story.append(Paragraph("Week 6 Update &mdash; COVID-19 Global Data Analysis", styles["H"]))
story.append(Paragraph("Shrey Jain &nbsp;&bull;&nbsp; Interactive Plotly charts for case &amp; death trends "
                       "&nbsp;&bull;&nbsp; Prepared for Neelam Gupta", styles["Sub"]))
rule()

# Weekly update
story.append(Paragraph("Weekly update", styles["Sec"]))
story.append(Paragraph(
    "This week I built four interactive Plotly charts for case and death trends, each exported as a "
    "standalone HTML file that opens in any browser and reproducible from the notebook. The images "
    "below are static previews &mdash; the live versions support hover, zoom, legend toggles, dropdowns, "
    "a range slider, and animation.", styles["Body"]))
story.append(Paragraph("<b>Built:</b>", styles["Body"]))
bullets([
    "<b>Global cases vs deaths</b> &mdash; dual-axis 7-day-smoothed trends with a range slider and "
    "3m / 6m / 1y / All quick-range buttons.",
    "<b>Country explorer</b> &mdash; a metric dropdown (new cases, new deaths, cumulative cases, "
    "cumulative deaths, all per million), a linear/log toggle, legend isolation, and a range slider.",
    "<b>Continent small multiples</b> &mdash; faceted new-cases-per-million panels with independent axes.",
    "<b>Animated world map</b> &mdash; a monthly choropleth of new cases per million with a play button "
    "and time slider.",
])
rule()

# Charts
story.append(Paragraph("Chart previews", styles["Sec"]))
figure("preview1.png", "Chart 1 preview &mdash; global new cases vs deaths. Live version adds a range "
       "slider and quick-range buttons.")
figure("preview2.png", "Chart 2 preview &mdash; country explorer (default metric shown). Live version "
       "adds a metric dropdown, log/linear toggle, and legend isolation.")
figure("preview3.png", "Chart 3 preview &mdash; continent small multiples with independent y-axes.")
figure("preview4.png", "Chart 4 preview &mdash; static heatmap of new cases/M by country over time; the "
       "live version is an animated world map.")
rule()

# Artifacts
story.append(Paragraph("Work artifacts &amp; data sources", styles["Sec"]))
art = [
    ["Repository", "github.com/shreyjain99/covid19-global-analysis"],
    ["Week 6 folder", "github.com/shreyjain99/covid19-global-analysis/tree/main/week%206"],
    ["Interactive charts", "charts/chart1&ndash;chart4 (.html) &mdash; open in any browser"],
    ["Week 6 notebook", "week6_interactive_charts.ipynb (renders all four inline)"],
    ["Data source", "Our World in Data COVID-19 dataset (github.com/owid/covid-19-data)"],
]
at = Table([[Paragraph(f"<b>{k}</b>", styles["Body"]), Paragraph(v, styles["Body"])] for k, v in art],
           colWidths=[1.5 * inch, 5.2 * inch])
at.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (0, -1), LIGHT), ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#d5dfe8")),
    ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
    ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
]))
story.append(at); story.append(Spacer(1, 6))

# Reproducibility
story.append(Paragraph("Reproducibility (how to re-run)", styles["Sec"]))
bullets([
    "<font face='Courier'>pip install -r requirements.txt</font>.",
    "Open <font face='Courier'>week6_interactive_charts.ipynb</font> and Run All &mdash; it downloads "
    "the dataset, renders all four charts inline, and writes the HTML copies into charts/.",
    "Or: <font face='Courier'>python scripts/build_charts.py</font> to regenerate the HTML charts, and "
    "<font face='Courier'>python scripts/build_week6_report.py</font> to rebuild this PDF.",
    "To view a chart, open any file in <font face='Courier'>charts/</font> in a web browser.",
])
rule()

# Risks
story.append(Paragraph("Risks / blockers &amp; support needed", styles["Sec"]))
bullets([
    "<b>No blockers to delivery.</b> The week's objective is met and reproducible.",
    "<b>Format note:</b> the charts are interactive HTML, so this PDF shows static previews; the live "
    "interactivity is in the .html files and the notebook.",
    "<b>Data note:</b> the animated map caps new cases/M at 2,500 so later spikes don't wash out the "
    "colour scale, and trends reflect each country's reporting cadence.",
    "<b>Support:</b> confirm the preferred delivery format (standalone HTML files vs an embedded "
    "dashboard) if these are to be shared more widely.",
])

SimpleDocTemplate(str(OUT), pagesize=letter, topMargin=0.7*inch, bottomMargin=0.6*inch,
                  leftMargin=0.75*inch, rightMargin=0.75*inch,
                  title="Week 6 Update - Interactive Plotly Charts for Case and Death Trends",
                  author="Shrey Jain").build(story)
print("PDF written:", OUT)
