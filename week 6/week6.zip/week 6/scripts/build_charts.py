"""
Week 6 — regenerate the four interactive Plotly HTML charts into charts/.

Self-contained: downloads the OWID dataset into data/ if missing.
Run:  python scripts/build_charts.py
Then open any file in charts/ in a web browser.
"""
from pathlib import Path
import urllib.request
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DATA = ROOT / "data" / "owid-covid-data.csv"
OUT = ROOT / "charts"
OUT.mkdir(exist_ok=True)
URL = ("https://raw.githubusercontent.com/owid/covid-19-data/"
       "master/public/data/owid-covid-data.csv")

FOCUS = ["United States", "India", "Brazil", "United Kingdom", "Germany",
         "South Africa", "Japan", "France", "Italy", "South Korea"]
palette = px.colors.qualitative.Bold + px.colors.qualitative.Safe


def load():
    if not DATA.exists():
        DATA.parent.mkdir(parents=True, exist_ok=True)
        print("Downloading OWID dataset (once)...")
        urllib.request.urlretrieve(URL, DATA)
    return pd.read_csv(DATA, low_memory=False, parse_dates=["date"])


def main():
    df = load()
    c = df[df.continent.notna()].copy()
    world = df[df.location == "World"].sort_values("date").set_index("date")

    # Chart 1 — global cases vs deaths, range slider + buttons
    f1 = make_subplots(specs=[[{"secondary_y": True}]])
    f1.add_trace(go.Scatter(x=world.index, y=world.new_cases_smoothed, name="New cases (7d)",
                 line=dict(color="#1f6fb4", width=1.6)), secondary_y=False)
    f1.add_trace(go.Scatter(x=world.index, y=world.new_deaths_smoothed, name="New deaths (7d)",
                 line=dict(color="#c0392b", width=1.6)), secondary_y=True)
    f1.update_yaxes(title_text="New cases / day", secondary_y=False)
    f1.update_yaxes(title_text="New deaths / day", secondary_y=True)
    f1.update_xaxes(rangeslider_visible=True, rangeselector=dict(buttons=[
        dict(count=3, label="3m", step="month", stepmode="backward"),
        dict(count=6, label="6m", step="month", stepmode="backward"),
        dict(count=1, label="1y", step="year", stepmode="backward"),
        dict(step="all", label="All")]))
    f1.update_layout(template="plotly_white", hovermode="x unified",
        title="Global daily new cases vs deaths (7-day smoothed)",
        legend=dict(orientation="h", y=1.02, x=1, xanchor="right", yanchor="bottom"))
    f1.write_html(OUT / "chart1_global_cases_deaths.html", include_plotlyjs="cdn")

    # Chart 2 — country explorer, metric dropdown + log toggle
    metrics = [("New cases / million (7d)", "new_cases_smoothed_per_million"),
               ("New deaths / million (7d)", "new_deaths_smoothed_per_million"),
               ("Cumulative cases / million", "total_cases_per_million"),
               ("Cumulative deaths / million", "total_deaths_per_million")]
    f2 = go.Figure()
    for mi, (mlabel, mcol) in enumerate(metrics):
        for ci, ct in enumerate(FOCUS):
            g = c[c.location == ct].sort_values("date")
            f2.add_trace(go.Scatter(x=g.date, y=g[mcol], name=ct, legendgroup=ct,
                line=dict(color=palette[ci % len(palette)], width=1.5), visible=(mi == 0),
                hovertemplate=f"{ct}<br>%{{x|%Y-%m-%d}}<br>%{{y:,.1f}}<extra></extra>"))
    n = len(FOCUS)
    def vis(mi): return [(j // n) == mi for j in range(n * len(metrics))]
    metric_buttons = [dict(label=ml, method="update", args=[{"visible": vis(mi)},
                      {"yaxis": {"title": ml}}]) for mi, (ml, _) in enumerate(metrics)]
    scale_buttons = [dict(label="Linear", method="relayout", args=[{"yaxis.type": "linear"}]),
                     dict(label="Log", method="relayout", args=[{"yaxis.type": "log"}])]
    f2.update_layout(template="plotly_white", hovermode="closest", yaxis_title=metrics[0][0],
        title="COVID-19 case & death trends explorer",
        updatemenus=[dict(buttons=metric_buttons, x=0.0, xanchor="left", y=1.16, yanchor="top", showactive=True),
                     dict(buttons=scale_buttons, type="buttons", direction="right",
                          x=1.0, xanchor="right", y=1.16, yanchor="top", showactive=True)])
    f2.update_xaxes(rangeslider_visible=True)
    f2.write_html(OUT / "chart2_country_explorer.html", include_plotlyjs="cdn")

    # Chart 3 — continent small multiples
    conts = ["Africa", "Asia", "Europe", "North America", "South America", "Oceania"]
    f3 = px.line(df[df.location.isin(conts)], x="date", y="new_cases_smoothed_per_million",
        facet_col="location", facet_col_wrap=3, color="location", template="plotly_white",
        labels={"new_cases_smoothed_per_million": "New cases / M", "date": ""},
        title="New cases per million by continent (7-day smoothed)")
    f3.update_layout(showlegend=False)
    f3.for_each_annotation(lambda a: a.update(text=a.text.split("=")[-1]))
    f3.update_yaxes(matches=None)
    f3.write_html(OUT / "chart3_continent_facets.html", include_plotlyjs="cdn")

    # Chart 4 — animated choropleth
    cc = c.copy()
    cc["month"] = cc["date"].dt.to_period("M").dt.to_timestamp()
    mon = (cc.groupby(["iso_code", "location", "month"])["new_cases_smoothed_per_million"]
           .mean().reset_index())
    mon = mon[(mon.month >= pd.Timestamp("2020-03-01")) & (mon.month <= pd.Timestamp("2023-06-01"))]
    mon["month_str"] = mon.month.dt.strftime("%Y-%m")
    mon["val"] = mon.new_cases_smoothed_per_million.clip(upper=2500)
    f4 = px.choropleth(mon.sort_values("month"), locations="iso_code", color="val",
        hover_name="location", animation_frame="month_str", color_continuous_scale="YlOrRd",
        range_color=(0, 2500), labels={"val": "New cases / M"}, template="plotly_white",
        title="New cases per million over time (monthly)")
    f4.write_html(OUT / "chart4_choropleth_animation.html", include_plotlyjs="cdn")

    print(f"Wrote 4 interactive HTML charts to {OUT}/")


if __name__ == "__main__":
    main()
