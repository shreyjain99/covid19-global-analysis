# Week 6 — Interactive Plotly Charts for Case & Death Trends

Part of **[COVID-19 Global Data Analysis](https://github.com/shreyjain99/covid19-global-analysis)**.

**Objective:** build interactive Plotly charts for case and death trends.

## Contents

```
week 6/
├── README.md                             ← you are here
├── Week6_Update_Interactive_Charts.pdf   ← status report (attach this)
├── week6_interactive_charts.ipynb        ← builds & renders all four charts (self-contained)
├── requirements.txt
├── charts/                               ← the deliverable: open these in a browser
│   ├── chart1_global_cases_deaths.html
│   ├── chart2_country_explorer.html
│   ├── chart3_continent_facets.html
│   └── chart4_choropleth_animation.html
├── figures/                              ← static previews used in the PDF
│   └── preview1..preview4.png
└── scripts/
    ├── build_charts.py                    ← regenerates charts/ (the HTML)
    └── build_week6_report.py              ← rebuilds the PDF from figures/
```

> `data/` (the ~98 MB OWID CSV) is downloaded on demand and is git-ignored.

## The charts

1. **Global cases vs deaths** — dual-axis 7-day-smoothed trends with a **range slider** and
   **3m / 6m / 1y / All** quick-range buttons.
2. **Country explorer** — a **metric dropdown** (new cases, new deaths, cumulative cases,
   cumulative deaths, all per million), a **linear/log toggle**, legend isolation, and a
   range slider.
3. **Continent small multiples** — faceted new-cases-per-million panels with independent axes.
4. **Animated world map** — a monthly **choropleth** of new cases per million with a **play
   button** and time slider.

## Reproduce

```bash
pip install -r requirements.txt

# Option A — interactive: open the notebook and Run All
#   (downloads the dataset, renders all four charts inline, writes charts/*.html)
jupyter notebook week6_interactive_charts.ipynb

# Option B — regenerate the HTML charts and the PDF from the command line
python scripts/build_charts.py          # writes charts/chart1..chart4.html
python scripts/build_week6_report.py    # writes Week6_Update_Interactive_Charts.pdf
```

To view a chart, open any file in `charts/` in a web browser.

## Interactivity used

Hover tooltips, legend isolation, range slider + range-selector buttons, `updatemenus`
(dropdown + buttons for metric and log/linear), independent facet axes, and an animation
frame slider.

## Data source

Our World in Data COVID-19 dataset — https://github.com/owid/covid-19-data
(429,435 rows × 67 columns; 2020-01-01 → 2024-08-14; ~230 countries).
