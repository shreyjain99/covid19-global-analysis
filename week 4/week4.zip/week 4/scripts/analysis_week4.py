"""
Week 4 — regenerate vaccination rollout charts and table into figures/.

Self-contained: downloads the OWID dataset into data/ if missing.
Run:  python scripts/analysis_week4.py
"""
from pathlib import Path
import urllib.request
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DATA = ROOT / "data" / "owid-covid-data.csv"
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)
URL = ("https://raw.githubusercontent.com/owid/covid-19-data/"
       "master/public/data/owid-covid-data.csv")

FOCUS = ["Israel", "United Arab Emirates", "Chile", "United Kingdom", "United States",
         "Germany", "Japan", "India", "South Africa", "Nigeria"]
plt.rcParams.update({"figure.dpi": 150, "font.size": 10, "axes.grid": True,
                     "grid.alpha": 0.25, "axes.spines.top": False, "axes.spines.right": False})
cmap = plt.get_cmap("tab10")


def load():
    if not DATA.exists():
        DATA.parent.mkdir(parents=True, exist_ok=True)
        print("Downloading OWID dataset (once)...")
        urllib.request.urlretrieve(URL, DATA)
    return pd.read_csv(DATA, low_memory=False, parse_dates=["date"])


def latest_valid(g, col):
    s = g.sort_values("date").dropna(subset=[col])
    return s[col].iloc[-1] if len(s) else np.nan


def days_to(g, thresh=40):
    g = g.sort_values("date")
    fv = g.dropna(subset=["people_vaccinated"])
    if fv.empty:
        return np.nan
    start = fv["date"].iloc[0]
    hit = g[g["people_fully_vaccinated_per_hundred"] >= thresh]
    return (hit["date"].iloc[0] - start).days if len(hit) else np.nan


def peak_daily(g):
    v = g["new_vaccinations_smoothed_per_million"]
    return v.max() / 1e4 if v.notna().any() else np.nan


def main():
    df = load()
    c = df[df.continent.notna()].copy()

    # Fig 1 — rollout curves
    fig, ax = plt.subplots(figsize=(9.2, 4.8))
    for i, ct in enumerate(FOCUS):
        g = c[c.location == ct].sort_values("date").dropna(subset=["people_fully_vaccinated_per_hundred"])
        if len(g):
            ax.plot(g.date, g.people_fully_vaccinated_per_hundred, lw=1.7, label=ct, color=cmap(i % 10))
    ax.set_ylabel("% fully vaccinated"); ax.set_ylim(0, 100)
    ax.set_title("Vaccination rollout curves — share fully vaccinated over time")
    ax.legend(fontsize=7.5, ncol=2, loc="lower right")
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    fig.tight_layout(); fig.savefig(FIG / "fig1_rollout_curves.png"); plt.close(fig)

    # metrics table
    metrics = c.groupby("location").apply(lambda g: pd.Series({
        "fully": latest_valid(g, "people_fully_vaccinated_per_hundred"),
        "one_dose": latest_valid(g, "people_vaccinated_per_hundred"),
        "peak_daily_per100": peak_daily(g),
        "days_to_40pct": days_to(g, 40),
        "continent": g.continent.iloc[0],
        "population": g.population.iloc[-1],
    })).reset_index()

    # Fig 2 — coverage top 15
    cov = metrics[metrics.population > 3_000_000].dropna(subset=["fully"])
    top15 = cov.nlargest(15, "fully").sort_values("fully")
    fig, ax = plt.subplots(figsize=(9, 5.2))
    ax.barh(top15.location, top15.fully, color="#2a9d8f")
    ax.set_xlabel("% fully vaccinated (latest)")
    ax.set_title("Coverage: top 15 countries by share fully vaccinated (pop > 3M)")
    for y, v in enumerate(top15.fully):
        ax.text(v, y, f" {v:.0f}%", va="center", fontsize=8.5)
    ax.axvline(100, color="#999", ls="--", lw=0.8)
    fig.tight_layout(); fig.savefig(FIG / "fig2_coverage_top15.png"); plt.close(fig)

    # Fig 3 — income inequity
    groups = ["High-income countries", "Upper-middle-income countries",
              "Lower-middle-income countries", "Low-income countries"]
    gcolors = {"High-income countries": "#1f6fb4", "Upper-middle-income countries": "#2a9d8f",
               "Lower-middle-income countries": "#e9a13b", "Low-income countries": "#c0392b"}
    fig, ax = plt.subplots(figsize=(9.2, 4.8))
    for grp in groups:
        g = df[df.location == grp].sort_values("date").dropna(subset=["people_fully_vaccinated_per_hundred"])
        if len(g):
            ax.plot(g.date, g.people_fully_vaccinated_per_hundred, lw=2,
                    label=grp.replace(" countries", ""), color=gcolors[grp])
    ax.set_ylabel("% fully vaccinated"); ax.set_ylim(0, 100)
    ax.set_title("Vaccination inequity — share fully vaccinated by income group")
    ax.legend(fontsize=8, loc="upper left")
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    fig.tight_layout(); fig.savefig(FIG / "fig3_income_inequity.png"); plt.close(fig)

    # Fig 4 — speed vs coverage
    sc = metrics[metrics.population > 3_000_000].dropna(subset=["days_to_40pct", "fully"])
    fig, ax = plt.subplots(figsize=(9, 5))
    for i, ct in enumerate(sorted(sc.continent.unique())):
        s = sc[sc.continent == ct]
        ax.scatter(s.days_to_40pct, s.fully, s=s.population / 3e6, alpha=0.6,
                   color=cmap(i), label=ct, edgecolor="white", lw=0.4)
    ax.set_xlabel("Days from first dose to reach 40% fully vaccinated  (faster \u2192 left)")
    ax.set_ylabel("Final % fully vaccinated")
    ax.set_title("Speed vs coverage (bubble = population; countries reaching 40%)")
    ax.legend(fontsize=7.5, title="Continent", loc="lower right")
    for name in ["Israel", "Chile", "United States", "Ireland", "India", "Japan"]:
        r = sc[sc.location == name]
        if len(r):
            ax.annotate(name, (r.days_to_40pct.iloc[0], r.fully.iloc[0]),
                        fontsize=7.5, xytext=(4, 4), textcoords="offset points")
    fig.tight_layout(); fig.savefig(FIG / "fig4_speed_vs_coverage.png"); plt.close(fig)

    # focus-set table
    tab = metrics[metrics.location.isin(FOCUS)].copy()
    tab["order"] = tab.location.map({n: i for i, n in enumerate(FOCUS)})
    tab = tab.sort_values("order")
    tab.rename(columns={"location": "country", "fully": "fully_pct",
                        "one_dose": "one_dose_pct"})[
        ["country" if "location" not in tab else "location"]] if False else None
    out = tab.rename(columns={"location": "country", "fully": "fully_pct", "one_dose": "one_dose_pct"})
    out[["country", "fully_pct", "one_dose_pct", "peak_daily_per100", "days_to_40pct"]].to_csv(
        FIG / "vax_table.csv", index=False)
    print(f"Wrote 4 charts + vax_table.csv to {FIG}/")


if __name__ == "__main__":
    main()
