"""Build the Week 4 status report PDF (vaccination rollout — speed & coverage)."""
import csv
from pathlib import Path
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Image,
                                Table, TableStyle, HRFlowable, ListFlowable, ListItem)

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FIG = ROOT / "figures"
OUT = ROOT / "Week4_Update_Vaccination_Rollout.pdf"

NAVY = colors.HexColor("#12395e"); BLUE = colors.HexColor("#1f6fb4")
GREY = colors.HexColor("#555555"); LIGHT = colors.HexColor("#eef3f8")
TEAL = colors.HexColor("#2a9d8f")

styles = getSampleStyleSheet()
styles.add(ParagraphStyle("H", parent=styles["Title"], fontSize=19, textColor=NAVY,
                          spaceAfter=2, alignment=TA_LEFT, leading=22))
styles.add(ParagraphStyle("Sub", fontName="Helvetica", fontSize=9.5, textColor=GREY, spaceAfter=10))
styles.add(ParagraphStyle("Sec", parent=styles["Heading2"], fontSize=12.5, textColor=BLUE,
                          spaceBefore=12, spaceAfter=5))
styles.add(ParagraphStyle("Body", parent=styles["Normal"], fontSize=10, leading=14.5,
                          textColor=colors.HexColor("#222222"), spaceAfter=5))
styles.add(ParagraphStyle("Cap", fontName="Helvetica-Oblique", fontSize=8.5, textColor=GREY,
                          spaceBefore=2, spaceAfter=10, alignment=1))
styles.add(ParagraphStyle("Bull", parent=styles["Body"], leftIndent=6, spaceAfter=3))
styles.add(ParagraphStyle("Cell", parent=styles["Body"], fontSize=8.8, spaceAfter=0))
styles.add(ParagraphStyle("CellR", parent=styles["Cell"], alignment=2))

story = []


def rule():
    story.append(Spacer(1, 3))
    story.append(HRFlowable(width="100%", thickness=0.7, color=colors.HexColor("#cdd9e5")))
    story.append(Spacer(1, 3))


def bullets(items):
    story.append(ListFlowable(
        [ListItem(Paragraph(t, styles["Bull"]), leftIndent=12, value="\u2022") for t in items],
        bulletType="bullet", start="\u2022", leftIndent=10))


def figure(name, caption, width=6.7 * inch):
    img = Image(str(FIG / name)); r = img.imageHeight / img.imageWidth
    img.drawWidth = width; img.drawHeight = width * r; img.hAlign = "CENTER"
    story.append(img); story.append(Paragraph(caption, styles["Cap"]))


# Header
story.append(Paragraph("Week 4 Update &mdash; COVID-19 Global Data Analysis", styles["H"]))
story.append(Paragraph("Shrey Jain &nbsp;&bull;&nbsp; Vaccination rollout: speed &amp; coverage by country "
                       "&nbsp;&bull;&nbsp; Prepared for Neelam Gupta", styles["Sub"]))
rule()

# Weekly update
story.append(Paragraph("Weekly update", styles["Sec"]))
story.append(Paragraph(
    "This week I analyzed vaccination rollout across countries along two axes: <b>coverage</b> "
    "(share of population fully vaccinated) and <b>speed</b> (peak daily doses per 100 people, and "
    "days from a country's first dose to reaching 40% fully vaccinated). Analysis uses country-level "
    "rows and OWID income-group aggregates, in a reproducible Plotly notebook.", styles["Body"]))
story.append(Paragraph("<b>Discovered:</b>", styles["Body"]))
bullets([
    "<b>Coverage varies enormously</b> &mdash; from ~90%+ fully vaccinated (United Arab Emirates, "
    "Singapore, Hong Kong, Chile, Cuba, China) down to low single digits in parts of Sub-Saharan "
    "Africa (e.g. Burundi ~0.3%).",
    "<b>Speed is a separate axis from coverage.</b> Israel vaccinated fastest early (peak ~2.0 "
    "doses/100/day, 40% in ~78 days); some slower starters still reached high coverage later (e.g. Japan).",
    "<b>Income group is the dominant divide</b> &mdash; high-income countries pulled far ahead early, "
    "while low-income countries lagged by a wide margin throughout.",
])
rule()

# Table
story.append(Paragraph("Focus set — speed &amp; coverage metrics", styles["Sec"]))
rows = [["Country", "Fully vax %", "1+ dose %", "Peak doses /100/day", "Days to 40%"]]
with open(FIG / "vax_table.csv") as f:
    for r in csv.DictReader(f):
        def fx(v, suf="", nd=0):
            return "n/a" if v in ("", "nan") else f"{float(v):.{nd}f}{suf}"
        rows.append([r["country"], fx(r["fully_pct"], "%"), fx(r["one_dose_pct"], "%"),
                     fx(r["peak_daily_per100"], "", 2), fx(r["days_to_40pct"])])
data = [[Paragraph(f"<b>{col}</b>", styles["Cell"]) if ri == 0 else
         Paragraph(col, styles["CellR"] if ci >= 1 else styles["Cell"])
         for ci, col in enumerate(row)] for ri, row in enumerate(rows)]
t = Table(data, colWidths=[1.7*inch, 1.0*inch, 1.0*inch, 1.5*inch, 1.0*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), TEAL), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
    ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#d5dfe8")),
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
]))
story.append(t)
story.append(Paragraph("Peak doses/100/day is the maximum 7-day-smoothed daily dose rate; "
                       "&ldquo;days to 40%&rdquo; is n/a where a country never reached 40% fully vaccinated.",
                       styles["Cap"]))

# Charts
story.append(Paragraph("Charts", styles["Sec"]))
figure("fig1_rollout_curves.png", "Fig 1. Rollout curves — steeper slope means faster rollout; the "
       "plateau height is final coverage.")
figure("fig2_coverage_top15.png", "Fig 2. Coverage: the 15 highest countries by share fully vaccinated "
       "(population > 3M). Dashed line marks 100%.")
figure("fig3_income_inequity.png", "Fig 3. Coverage by income group — the widest and most persistent gap "
       "in the data.")
figure("fig4_speed_vs_coverage.png", "Fig 4. Speed (days to 40%, faster to the left) vs final coverage; "
       "bubble size is population.")
rule()

# Artifacts
story.append(Paragraph("Work artifacts &amp; data sources", styles["Sec"]))
art = [
    ["Repository", "github.com/shreyjain99/covid19-global-analysis"],
    ["Week 4 folder", "github.com/shreyjain99/covid19-global-analysis/tree/main/week%204"],
    ["Week 4 notebook", "week4_vaccination_rollout.ipynb (interactive Plotly)"],
    ["Charts", "figures/fig1&ndash;fig4 (.png) + vax_table.csv"],
    ["Data source", "Our World in Data COVID-19 dataset (github.com/owid/covid-19-data)"],
]
at = Table([[Paragraph(f"<b>{k}</b>", styles["Body"]), Paragraph(v, styles["Body"])] for k, v in art],
           colWidths=[1.5 * inch, 5.2 * inch])
at.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (0, -1), LIGHT), ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#d5dfe8")),
    ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
    ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
]))
story.append(at); story.append(Spacer(1, 6))

# Reproducibility
story.append(Paragraph("Reproducibility (how to re-run)", styles["Sec"]))
bullets([
    "<font face='Courier'>pip install -r requirements.txt</font>.",
    "Open <font face='Courier'>week4_vaccination_rollout.ipynb</font> and Run All &mdash; it downloads "
    "the dataset automatically and regenerates every figure from the raw data.",
    "Or from the command line: <font face='Courier'>python scripts/analysis_week4.py</font> (charts) "
    "then <font face='Courier'>python scripts/build_week4_report.py</font> (this PDF).",
])
rule()

# Risks
story.append(Paragraph("Risks / blockers &amp; support needed", styles["Sec"]))
bullets([
    "<b>No blockers to delivery.</b> The week's objective is met and reproducible.",
    "<b>Data caveat:</b> per-hundred metrics can exceed 100% where doses are administered to "
    "non-resident / migrant populations (e.g. UAE), and rollout figures depend on national reporting "
    "cadence, so exact dates and rates carry some uncertainty.",
    "<b>Support:</b> confirm whether the 40% threshold is the preferred speed milestone, or another "
    "level (e.g. 70%) is expected for this comparison.",
])

SimpleDocTemplate(str(OUT), pagesize=letter, topMargin=0.7*inch, bottomMargin=0.6*inch,
                  leftMargin=0.75*inch, rightMargin=0.75*inch,
                  title="Week 4 Update - Vaccination Rollout: Speed and Coverage",
                  author="Shrey Jain").build(story)
print("PDF written:", OUT)
