# Week 4 — Vaccination Rollout: Speed & Coverage by Country

Part of **[COVID-19 Global Data Analysis](https://github.com/shreyjain99/covid19-global-analysis)**.

**Objective:** analyze vaccination rollout — speed and coverage by country.

## Contents

```
week 4/
├── README.md                              ← you are here
├── Week4_Update_Vaccination_Rollout.pdf   ← status report (attach this)
├── week4_vaccination_rollout.ipynb        ← interactive Plotly analysis (self-contained)
├── requirements.txt
├── figures/                               ← charts (.png) + vax_table.csv
│   ├── fig1_rollout_curves.png
│   ├── fig2_coverage_top15.png
│   ├── fig3_income_inequity.png
│   ├── fig4_speed_vs_coverage.png
│   └── vax_table.csv
└── scripts/
    ├── analysis_week4.py                   ← regenerates figures/ + table
    └── build_week4_report.py               ← rebuilds the PDF from figures/
```

> `data/` (the ~98 MB OWID CSV) is downloaded on demand and is git-ignored.

## Reproduce

```bash
pip install -r requirements.txt

# Option A — interactive: open the notebook and Run All
#   (it downloads the dataset into data/ automatically on first run)
jupyter notebook week4_vaccination_rollout.ipynb

# Option B — regenerate the static charts and PDF from the command line
python scripts/analysis_week4.py        # writes figures/fig1..fig4 + vax_table.csv
python scripts/build_week4_report.py    # writes Week4_Update_Vaccination_Rollout.pdf
```

## Method

- **Coverage** — each country's latest `people_fully_vaccinated_per_hundred` (and
  `people_vaccinated_per_hundred` for at-least-one-dose).
- **Speed** — peak 7-day-smoothed daily dose rate (doses per 100 people/day), and days
  from a country's first dose to first crossing 40% fully vaccinated.
- Income-group comparison uses OWID's World Bank income aggregates.

## Key findings

- **Coverage varies enormously** — ~90%+ fully vaccinated (United Arab Emirates, Singapore,
  Hong Kong, Chile, Cuba, China) down to low single digits in parts of Sub-Saharan Africa
  (e.g. Burundi ~0.3%).
- **Speed is a separate axis from coverage.** Israel vaccinated fastest early (peak ~2.0
  doses/100/day, 40% in ~78 days); some slower starters still reached high coverage later
  (e.g. Japan ~83%).
- **Income group is the dominant divide** — high-income countries pulled far ahead early,
  low-income countries lagged by a wide margin throughout.

**Caveat:** per-hundred metrics can exceed 100% where doses are given to non-resident /
migrant populations (e.g. UAE), and rollout figures depend on national reporting cadence.

## Data source

Our World in Data COVID-19 dataset — https://github.com/owid/covid-19-data
(429,435 rows × 67 columns; 2020-01-01 → 2024-08-14; ~230 countries).
