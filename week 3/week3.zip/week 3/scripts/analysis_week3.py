"""
Week 3 — regenerate the top-10 case/CFR charts and table into figures/.

Self-contained: downloads the OWID dataset into data/ if missing.
Run:  python scripts/analysis_week3.py
"""
from pathlib import Path
import urllib.request
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DATA = ROOT / "data" / "owid-covid-data.csv"
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)
URL = ("https://raw.githubusercontent.com/owid/covid-19-data/"
       "master/public/data/owid-covid-data.csv")

BLUE, RED, TEAL, PURP = "#1f6fb4", "#c0392b", "#2a9d8f", "#8d6e9c"
plt.rcParams.update({"figure.dpi": 150, "font.size": 10, "axes.grid": True,
                     "grid.alpha": 0.25, "axes.spines.top": False, "axes.spines.right": False})
mfmt = FuncFormatter(lambda x, _: f"{x/1e6:.0f}M" if abs(x) >= 1e6 else f"{x/1e3:.0f}K")


def load():
    if not DATA.exists():
        DATA.parent.mkdir(parents=True, exist_ok=True)
        print("Downloading OWID dataset (once)...")
        urllib.request.urlretrieve(URL, DATA)
    return pd.read_csv(DATA, low_memory=False, parse_dates=["date"])


def main():
    df = load()
    c = df[df.continent.notna()].copy()
    latest = c.sort_values("date").groupby("location", as_index=False).last()
    latest["cfr"] = 100 * latest["total_deaths"] / latest["total_cases"]
    top = latest.nlargest(10, "total_cases").copy()

    # Fig 1 — top 10 by cases
    t = top.sort_values("total_cases")
    fig, ax = plt.subplots(figsize=(9, 4.8))
    ax.barh(t.location, t.total_cases, color=BLUE)
    ax.xaxis.set_major_formatter(mfmt); ax.set_xlabel("Total confirmed cases")
    ax.set_title("Top 10 countries by total confirmed COVID-19 cases")
    for y, v in enumerate(t.total_cases):
        ax.text(v, y, f" {v/1e6:.1f}M", va="center", fontsize=8.5)
    fig.tight_layout(); fig.savefig(FIG / "fig1_top10_cases.png"); plt.close(fig)

    # Fig 2 — CFR sorted
    t = top.sort_values("cfr")
    cols = [RED if v == t.cfr.max() else (TEAL if v == t.cfr.min() else "#6a8caf") for v in t.cfr]
    fig, ax = plt.subplots(figsize=(9, 4.8))
    ax.barh(t.location, t.cfr, color=cols); ax.set_xlabel("Naive case-fatality rate (%)")
    ax.set_title("Fatality rate of the top-10-by-cases countries (deaths / cases)")
    for y, v in enumerate(t.cfr):
        ax.text(v, y, f" {v:.2f}%", va="center", fontsize=8.5)
    fig.tight_layout(); fig.savefig(FIG / "fig2_top10_cfr.png"); plt.close(fig)

    # Fig 3 — combined
    t = top.sort_values("total_cases", ascending=False)
    x = np.arange(len(t))
    fig, ax = plt.subplots(figsize=(9.2, 4.8))
    ax.bar(x, t.total_cases, color=BLUE, alpha=0.85)
    ax.set_ylabel("Total cases", color=BLUE); ax.tick_params(axis="y", labelcolor=BLUE)
    ax.yaxis.set_major_formatter(mfmt)
    ax.set_xticks(x); ax.set_xticklabels(t.location, rotation=35, ha="right", fontsize=8.5)
    a2 = ax.twinx(); a2.grid(False)
    a2.plot(x, t.cfr, color=RED, marker="o", lw=1.6)
    a2.set_ylabel("Naive CFR (%)", color=RED); a2.tick_params(axis="y", labelcolor=RED)
    a2.set_ylim(0, max(2.2, t.cfr.max() * 1.25))
    for xi, v in zip(x, t.cfr):
        a2.text(xi, v + 0.05, f"{v:.2f}%", ha="center", fontsize=7.5, color=RED)
    ax.set_title("Top 10 by total cases vs their fatality rate")
    fig.tight_layout(); fig.savefig(FIG / "fig3_cases_vs_cfr.png"); plt.close(fig)

    # Fig 4 — deaths per million
    t = top.sort_values("total_deaths_per_million")
    fig, ax = plt.subplots(figsize=(9, 4.8))
    ax.barh(t.location, t.total_deaths_per_million, color=PURP)
    ax.set_xlabel("Total deaths per million")
    ax.set_title("Deaths per million among the top-10-by-cases countries")
    for y, v in enumerate(t.total_deaths_per_million):
        ax.text(v, y, f" {v:,.0f}", va="center", fontsize=8.5)
    fig.tight_layout(); fig.savefig(FIG / "fig4_top10_deaths_per_million.png"); plt.close(fig)

    # Table
    (top.sort_values("total_cases", ascending=False)
        [["location", "total_cases", "total_deaths", "cfr", "total_deaths_per_million"]]
        .to_csv(FIG / "top10_table.csv", index=False))
    print(f"Wrote 4 charts + top10_table.csv to {FIG}/")


if __name__ == "__main__":
    main()
