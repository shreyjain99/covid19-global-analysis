"""Build the Week 3 status report PDF (top 10 countries by cases & fatality rate)."""
import csv
from pathlib import Path
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Image,
                                Table, TableStyle, HRFlowable, ListFlowable, ListItem)

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FIG = ROOT / "figures"
OUT = ROOT / "Week3_Update_Top10_Cases_CFR.pdf"

NAVY = colors.HexColor("#12395e"); BLUE = colors.HexColor("#1f6fb4")
GREY = colors.HexColor("#555555"); LIGHT = colors.HexColor("#eef3f8")

styles = getSampleStyleSheet()
styles.add(ParagraphStyle("H", parent=styles["Title"], fontSize=19, textColor=NAVY,
                          spaceAfter=2, alignment=TA_LEFT, leading=22))
styles.add(ParagraphStyle("Sub", fontName="Helvetica", fontSize=9.5, textColor=GREY, spaceAfter=10))
styles.add(ParagraphStyle("Sec", parent=styles["Heading2"], fontSize=12.5, textColor=BLUE,
                          spaceBefore=12, spaceAfter=5))
styles.add(ParagraphStyle("Body", parent=styles["Normal"], fontSize=10, leading=14.5,
                          textColor=colors.HexColor("#222222"), spaceAfter=5))
styles.add(ParagraphStyle("Cap", fontName="Helvetica-Oblique", fontSize=8.5, textColor=GREY,
                          spaceBefore=2, spaceAfter=10, alignment=1))
styles.add(ParagraphStyle("Bull", parent=styles["Body"], leftIndent=6, spaceAfter=3))
styles.add(ParagraphStyle("Cell", parent=styles["Body"], fontSize=8.8, spaceAfter=0))
styles.add(ParagraphStyle("CellR", parent=styles["Cell"], alignment=2))

story = []


def rule():
    story.append(Spacer(1, 3))
    story.append(HRFlowable(width="100%", thickness=0.7, color=colors.HexColor("#cdd9e5")))
    story.append(Spacer(1, 3))


def bullets(items):
    story.append(ListFlowable(
        [ListItem(Paragraph(t, styles["Bull"]), leftIndent=12, value="\u2022") for t in items],
        bulletType="bullet", start="\u2022", leftIndent=10))


def figure(name, caption, width=6.7 * inch):
    img = Image(str(FIG / name)); r = img.imageHeight / img.imageWidth
    img.drawWidth = width; img.drawHeight = width * r; img.hAlign = "CENTER"
    story.append(img); story.append(Paragraph(caption, styles["Cap"]))


# Header
story.append(Paragraph("Week 3 Update &mdash; COVID-19 Global Data Analysis", styles["H"]))
story.append(Paragraph("Shrey Jain &nbsp;&bull;&nbsp; Top 10 countries by total cases &amp; fatality rate "
                       "&nbsp;&bull;&nbsp; Prepared for Neelam Gupta", styles["Sub"]))
rule()

# Weekly update
story.append(Paragraph("Weekly update", styles["Sec"]))
story.append(Paragraph(
    "This week I ranked countries by total confirmed cases, took the top 10, and compared "
    "them on fatality rate (naive CFR = deaths / cases) and deaths per million. Analysis uses "
    "country-level rows only (aggregates such as <i>World</i> and income groups are excluded) "
    "and each country's latest record, in a reproducible Plotly notebook.", styles["Body"]))
story.append(Paragraph("<b>Discovered:</b>", styles["Body"]))
bullets([
    "<b>Fatality rate varies widely</b> across the top-10-by-cases group &mdash; from ~0.10% "
    "(South Korea) and ~0.12% (China) up to ~1.87% (Brazil) and ~1.18% (India).",
    "<b>High case counts do not imply high fatality.</b> Several of the largest-case countries "
    "(South Korea, Japan, China) sit at the low end of CFR.",
    "On <b>deaths per million</b>, the United States (~3,490) and United Kingdom (~3,400) lead the "
    "group; China (~86) and India (~374) are lowest.",
    "<b>Brazil</b> is the notable case: large case count and the highest CFR in the group.",
])
rule()

# Table
story.append(Paragraph("Top 10 countries by total cases", styles["Sec"]))
rows = [["#", "Country", "Total cases", "Total deaths", "CFR", "Deaths / M"]]
with open(FIG / "top10_table.csv") as f:
    for i, r in enumerate(csv.DictReader(f), 1):
        rows.append([str(i), r["location"], f"{float(r['total_cases']):,.0f}",
                     f"{float(r['total_deaths']):,.0f}", f"{float(r['cfr']):.2f}%",
                     f"{float(r['total_deaths_per_million']):,.0f}"])
data = [[Paragraph(f"<b>{c}</b>", styles["Cell"]) if ri == 0 else
         Paragraph(c, styles["CellR"] if ci >= 2 else styles["Cell"])
         for ci, c in enumerate(row)] for ri, row in enumerate(rows)]
t = Table(data, colWidths=[0.3*inch, 1.5*inch, 1.2*inch, 1.15*inch, 0.75*inch, 0.95*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), BLUE),
    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
    ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#d5dfe8")),
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
]))
story.append(t)
story.append(Spacer(1, 8))

# Charts
story.append(Paragraph("Comparison charts", styles["Sec"]))
figure("fig1_top10_cases.png", "Fig 1. Top 10 countries by total confirmed cases.")
figure("fig2_top10_cfr.png", "Fig 2. Naive fatality rate (CFR) for the same 10 countries, sorted. "
       "Lowest in teal (South Korea), highest in red (Brazil).")
figure("fig3_cases_vs_cfr.png", "Fig 3. Direct comparison: total cases (bars) vs fatality rate "
       "(red markers). The two do not track each other.")
figure("fig4_top10_deaths_per_million.png", "Fig 4. Deaths per million &mdash; a population-adjusted "
       "mortality view for the same group.")
rule()

# Artifacts
story.append(Paragraph("Work artifacts &amp; data sources", styles["Sec"]))
art = [
    ["Repository", "github.com/shreyjain99/covid19-global-analysis"],
    ["Week 3 folder", "github.com/shreyjain99/covid19-global-analysis/tree/main/week%203"],
    ["Week 3 notebook", "week3_top10_cases_cfr.ipynb (interactive Plotly)"],
    ["Charts", "figures/fig1&ndash;fig4 (.png) + top10_table.csv"],
    ["Data source", "Our World in Data COVID-19 dataset (github.com/owid/covid-19-data)"],
]
at = Table([[Paragraph(f"<b>{k}</b>", styles["Body"]), Paragraph(v, styles["Body"])] for k, v in art],
           colWidths=[1.5 * inch, 5.2 * inch])
at.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (0, -1), LIGHT), ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#d5dfe8")),
    ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
    ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
]))
story.append(at); story.append(Spacer(1, 6))

# Reproducibility
story.append(Paragraph("Reproducibility (how to re-run)", styles["Sec"]))
bullets([
    "<font face='Courier'>pip install -r requirements.txt</font>.",
    "Open <font face='Courier'>week3_top10_cases_cfr.ipynb</font> and Run All &mdash; it downloads "
    "the dataset automatically and regenerates every figure from the raw data.",
    "Or from the command line: <font face='Courier'>python scripts/analysis_week3.py</font> "
    "(charts) then <font face='Courier'>python scripts/build_week3_report.py</font> (this PDF).",
])
rule()

# Risks
story.append(Paragraph("Risks / blockers &amp; support needed", styles["Sec"]))
bullets([
    "<b>No blockers to delivery.</b> The week's objective is met and reproducible.",
    "<b>Measurement caveat:</b> naive CFR and reported totals depend on each country's testing "
    "and death-reporting practices, so cross-country CFR gaps partly reflect measurement rather "
    "than lethality (China's reported figures in particular are widely regarded as undercounts).",
    "<b>Support:</b> confirm whether reported CFR is acceptable for this comparison, or whether an "
    "adjusted / excess-mortality basis is preferred.",
])

SimpleDocTemplate(str(OUT), pagesize=letter, topMargin=0.7*inch, bottomMargin=0.6*inch,
                  leftMargin=0.75*inch, rightMargin=0.75*inch,
                  title="Week 3 Update - Top 10 Countries by Cases and CFR",
                  author="Shrey Jain").build(story)
print("PDF written:", OUT)
