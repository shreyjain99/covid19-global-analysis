# Week 3 — Top 10 Countries by Total Cases & Fatality Rate

Part of **[COVID-19 Global Data Analysis](https://github.com/shreyjain99/covid19-global-analysis)**.

**Objective:** compare the top 10 countries by total cases and their fatality rate.

## Contents

```
week 3/
├── README.md                              ← you are here
├── Week3_Update_Top10_Cases_CFR.pdf       ← status report (attach this)
├── week3_top10_cases_cfr.ipynb            ← interactive Plotly analysis (self-contained)
├── requirements.txt
├── figures/                               ← charts (.png) + top10_table.csv
│   ├── fig1_top10_cases.png
│   ├── fig2_top10_cfr.png
│   ├── fig3_cases_vs_cfr.png
│   ├── fig4_top10_deaths_per_million.png
│   └── top10_table.csv
└── scripts/
    ├── analysis_week3.py                   ← regenerates figures/ + table
    └── build_week3_report.py               ← rebuilds the PDF from figures/
```

> `data/` (the ~98 MB OWID CSV) is downloaded on demand and is git-ignored.

## Reproduce

```bash
pip install -r requirements.txt

# Option A — interactive: open the notebook and Run All
#   (it downloads the dataset into data/ automatically on first run)
jupyter notebook week3_top10_cases_cfr.ipynb

# Option B — regenerate the static charts and PDF from the command line
python scripts/analysis_week3.py        # writes figures/fig1..fig4 + top10_table.csv
python scripts/build_week3_report.py    # writes Week3_Update_Top10_Cases_CFR.pdf
```

## Method

Country-level rows only (aggregates such as `World` and income groups are excluded), each
country's latest record, ranked by `total_cases`. Fatality rate is the naive
CFR = `total_deaths / total_cases`.

## Key findings

- **Top 10 by total cases:** United States, China, India, France, Germany, Brazil,
  South Korea, Japan, Italy, United Kingdom.
- **Fatality rate varies widely** within the group — ~0.10% (South Korea) and ~0.12%
  (China) up to ~1.87% (Brazil) and ~1.18% (India). High case counts do **not** imply a
  high fatality rate.
- **Deaths per million:** United States (~3,490) and United Kingdom (~3,400) are highest;
  China (~86) and India (~374) are lowest.
- **Brazil** combines a large case count with the highest CFR in the group.

**Caveat:** naive CFR and reported totals depend on each country's testing and
death-reporting practices, so cross-country differences partly reflect measurement rather
than lethality (China's reported figures in particular are widely regarded as undercounts).

## Data source

Our World in Data COVID-19 dataset — https://github.com/owid/covid-19-data
(429,435 rows × 67 columns; 2020-01-01 → 2024-08-14; ~230 countries).
